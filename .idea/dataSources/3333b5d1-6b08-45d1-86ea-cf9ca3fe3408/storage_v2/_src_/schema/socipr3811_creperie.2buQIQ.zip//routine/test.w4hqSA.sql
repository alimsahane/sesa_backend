create
    definer = socipr3811_root@`%` procedure test(IN p int, IN te varchar(100))
BEGIN
	IF te="orders" THEN
		SELECT * FROM orders
		WHERE user_id = p;
	ELSEIF te="carts" THEN
		SELECT * FROM carts
		WHERE user_id = p;
	END IF;
END;

